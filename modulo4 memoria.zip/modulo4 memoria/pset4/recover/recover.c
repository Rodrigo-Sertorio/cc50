#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

typedef uint8_t BYTE; // Definindo BYTE como uint8_t para representar um byte de dados

int main(int argc, char *argv[])
{
    // Verificar se o programa foi chamado com exatamente um argumento
    if (argc != 2)
    {
        printf("Uso: ./recover imagem\n");
        return 1; // Se não, retorna erro
    }

    // Tentar abrir o arquivo fornecido como argumento
    FILE *file = fopen(argv[1], "r");
    if (file == NULL)
    {
        printf("Não foi possível abrir o arquivo.\n");
        return 1; // Se o arquivo não for encontrado, retorna erro
    }

    BYTE buffer[512];  // Buffer para armazenar 512 bytes por vez
    int jpeg_count = 0; // Contador para numerar os arquivos JPEG
    FILE *img = NULL;   // Ponteiro para o arquivo JPEG atual

    // Ler o arquivo forense em blocos de 512 bytes
    while (fread(buffer, sizeof(BYTE), 512, file) == 512)
    {
        // Verificar se encontramos o início de um JPEG (assinado por 0xff 0xd8 0xff e seguido por um byte 0xe0 a 0xef)
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff &&
            (buffer[3] >= 0xe0 && buffer[3] <= 0xef))
        {
            // Se já houver um arquivo JPEG aberto, fechá-lo
            if (img != NULL)
            {
                fclose(img);
            }

            // Criar um novo nome de arquivo para o JPEG
            char filename[8];
            sprintf(filename, "%03d.jpg", jpeg_count++);  // Formato: 000.jpg, 001.jpg, ...
            img = fopen(filename, "w");  // Abrir o arquivo para escrita

            // Escrever o primeiro bloco de 512 bytes no novo arquivo JPEG
            fwrite(buffer, sizeof(BYTE), 512, img);
        }
        // Caso o arquivo JPEG já tenha começado, continuar escrevendo nele
        else if (img != NULL)
        {
            fwrite(buffer, sizeof(BYTE), 512, img);
        }
    }

    // Fechar qualquer arquivo JPEG que ainda esteja aberto
    if (img != NULL)
    {
        fclose(img);
    }

    // Fechar o arquivo forense
    fclose(file);

    return 0; // Sucesso
}
