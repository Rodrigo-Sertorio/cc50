// filter.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "helpers.h"
#include "bmp.h"


// Prototipo da função para o filtro
void apply_filter(char *filter_name, int height, int width, RGBTRIPLE image[height][width]);

int main(int argc, char *argv[])
{
    // Verifica se o número de argumentos está correto
    if (argc != 3)
    {
        printf("Uso: %s <filtro> <arquivo.bmp>\n", argv[0]);
        return 1;
    }

    // Lê o nome do filtro
    char *filter_name = argv[1];

    // Abre o arquivo BMP
    FILE *infile = fopen(argv[2], "rb");
    if (infile == NULL)
    {
        printf("Erro ao abrir o arquivo\n");
        return 1;
    }

    // Lê o cabeçalho BMP
    BITMAPFILEHEADER bf;
    BITMAPINFOHEADER bi;
    fread(&bf, sizeof(BITMAPFILEHEADER), 1, infile);
    fread(&bi, sizeof(BITMAPINFOHEADER), 1, infile);

    // Verifica o tipo de arquivo BMP
    if (bf.bfType != 0x4D42)
    {
        printf("Arquivo não é um BMP\n");
        fclose(infile);
        return 1;
    }

    // Aloca memória para a imagem
    RGBTRIPLE image[bi.biHeight][bi.biWidth];

    // Lê os pixels da imagem
    for (int i = 0; i < bi.biHeight; i++)
    {
        for (int j = 0; j < bi.biWidth; j++)
        {
            fread(&image[i][j], sizeof(RGBTRIPLE), 1, infile);
        }
    }

    // Aplica o filtro especificado
    apply_filter(filter_name, bi.biHeight, bi.biWidth, image);

    // Abre o arquivo de saída
    FILE *outfile = fopen("output.bmp", "wb");
    if (outfile == NULL)
    {
        printf("Erro ao abrir o arquivo de saída\n");
        fclose(infile);
        return 1;
    }

    // Escreve o cabeçalho BMP de volta no arquivo
    fwrite(&bf, sizeof(BITMAPFILEHEADER), 1, outfile);
    fwrite(&bi, sizeof(BITMAPINFOHEADER), 1, outfile);

    // Escreve os pixels modificados no arquivo de saída
    for (int i = 0; i < bi.biHeight; i++)
    {
        for (int j = 0; j < bi.biWidth; j++)
        {
            fwrite(&image[i][j], sizeof(RGBTRIPLE), 1, outfile);
        }
    }

    // Fecha os arquivos
    fclose(infile);
    fclose(outfile);

    return 0;
}
