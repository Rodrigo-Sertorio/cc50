#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define HEADER_SIZE 44

int main(int argc, char *argv[])
{
    // Verifica argumentos da linha de comando
    if (argc != 4)
    {
        printf("Usage: ./volume input.wav output.wav factor\n");
        return 1;
    }

    // Abre arquivos
    FILE *input = fopen(argv[1], "rb");
    if (input == NULL)
    {
        printf("Could not open file %s.\n", argv[1]);
        return 1;
    }

    FILE *output = fopen(argv[2], "wb");
    if (output == NULL)
    {
        printf("Could not open file %s.\n", argv[2]);
        fclose(input);
        return 1;
    }

    // Converte factor para float
    float factor = atof(argv[3]);

    // Lê e escreve cabeçalho
    uint8_t header[HEADER_SIZE];
    fread(header, sizeof(uint8_t), HEADER_SIZE, input);
    fwrite(header, sizeof(uint8_t), HEADER_SIZE, output);

    // Lê e processa as amostras de áudio
    int16_t buffer;
    while (fread(&buffer, sizeof(int16_t), 1, input))
    {
        buffer = buffer * factor;
        fwrite(&buffer, sizeof(int16_t), 1, output);
    }

    // Fecha os arquivos
    fclose(input);
    fclose(output);

    return 0;
}
