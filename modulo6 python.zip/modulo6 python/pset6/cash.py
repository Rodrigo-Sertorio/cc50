from cs50 import get_float

def get_change():
    """
    Solicita ao usuário um valor de troco não negativo.
    Continua pedindo até que um valor válido seja inserido.
    Retorna o troco em centavos como um inteiro.
    """
    while True:
        try:
            change = get_float("Change owed: ")
            if change >= 0:
                return round(change * 100)  # Converte para centavos para evitar erros de ponto flutuante
        except ValueError:
            pass  # Se o input não for um número, repete o loop.

def calculate_coins(cents):
    """
    Calcula o número mínimo de moedas necessárias para o troco.
    Retorna a quantidade mínima de moedas.
    """
    coins = 0
    for coin in [25, 10, 5, 1]:  # Lista de moedas disponíveis (em centavos)
        coins += cents // coin  # Quantidade de moedas dessa denominação
        cents %= coin  # Atualiza o troco restante
    return coins

# Executando o programa
if __name__ == "__main__":
    cents = get_change()
    print(calculate_coins(cents))
