from cs50 import get_string
import re

def count_letters(text):
    """Conta o número de letras no texto."""
    return sum(1 for char in text if char.isalpha())

def count_words(text):
    """Conta o número de palavras no texto, assumindo que são separadas por espaços."""
    return len(text.split())

def count_sentences(text):
    """Conta o número de frases no texto, assumindo que terminam com '.', '!' ou '?'."""
    return len(re.findall(r'[.!?]', text))

def calculate_readability(text):
    """Calcula o índice de Coleman-Liau e retorna o nível de leitura correspondente."""
    letters = count_letters(text)
    words = count_words(text)
    sentences = count_sentences(text)

    # Cálculo das médias para 100 palavras
    L = (letters / words) * 100
    S = (sentences / words) * 100

    # Fórmula de Coleman-Liau
    index = round(0.0588 * L - 0.296 * S - 15.8)

    # Determinação do nível de leitura
    if index < 1:
        return "Before Grade 1"
    elif index >= 16:
        return "Grade 16+"
    else:
        return f"Grade {index}"

# Obtém a entrada do usuário
text = get_string("Text: ")

# Calcula e imprime o nível de legibilidade
print(calculate_readability(text))
