def get_height():
    """
    Solicita ao usuário um número inteiro entre 1 e 8.
    Continua pedindo até que um valor válido seja inserido.
    Retorna a altura como um inteiro.
    """
    while True:
        try:
            height = int(input("Height: "))
            if 1 <= height <= 8:
                return height
        except ValueError:
            pass  # Se o input não for um número inteiro, repete o loop.

def print_pyramids(height):
    """
    Imprime duas meias pirâmides de altura `height`,
    separadas por dois espaços.
    """
    for i in range(1, height + 1):
        print(" " * (height - i) + "#" * i + "  " + "#" * i)

# Executando o programa
if __name__ == "__main__":
    height = get_height()
    print_pyramids(height)
