from cs50 import get_string

def luhn_algorithm(card_number):
    """
    Implementa o algoritmo de Luhn para verificar a validade do número do cartão.
    Retorna True se for válido, False caso contrário.
    """
    total_sum = 0
    num_digits = len(card_number)

    # Percorre os dígitos do cartão de trás para frente
    for i in range(num_digits):
        digit = int(card_number[num_digits - 1 - i])

        # Dobra os dígitos em posições alternadas (começando do penúltimo)
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9  # Soma os dígitos do resultado

        total_sum += digit

    return total_sum % 10 == 0  # O número é válido se a soma for múltiplo de 10

def get_card_type(card_number):
    """
    Determina o tipo do cartão com base no número de dígitos e prefixo.
    Retorna "AMEX", "MASTERCARD", "VISA" ou "INVALID".
    """
    num_digits = len(card_number)

    if num_digits == 15 and card_number.startswith(("34", "37")):
        return "AMEX"
    elif num_digits == 16 and card_number.startswith(("51", "52", "53", "54", "55")):
        return "MASTERCARD"
    elif num_digits in [13, 16] and card_number.startswith("4"):
        return "VISA"
    else:
        return "INVALID"

# Obtém a entrada do usuário
card_number = get_string("Number: ")

# Verifica validade e tipo do cartão
if luhn_algorithm(card_number):
    print(get_card_type(card_number))
else:
    print("INVALID")
