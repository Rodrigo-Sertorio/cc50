#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Funções auxiliares para validar e criptografar a chave
bool validate_key(string key);
char encrypt_char(char c, string key);

int main(int argc, string argv[])
{
    // Verifique se o programa foi executado com um único argumento de linha de comando
    if (argc != 2)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }

    // Valide a chave
    string key = argv[1];
    if (!validate_key(key))
    {
        printf("Key must contain 26 unique alphabetical characters.\n");
        return 1;
    }

    // Solicite texto simples ao usuário
    string plaintext = get_string("texto simples: ");

    // Criptografe o texto
    printf("texto cifrado: ");
    for (int i = 0, n = strlen(plaintext); i < n; i++)
    {
        printf("%c", encrypt_char(plaintext[i], key));
    }
    printf("\n");

    return 0;
}

// Função para validar a chave
bool validate_key(string key)
{
    if (strlen(key) != 26)
    {
        return false;
    }

    bool letters[26] = {false};
    for (int i = 0; i < 26; i++)
    {
        if (!isalpha(key[i]))
        {
            return false;
        }
        int index = toupper(key[i]) - 'A';
        if (letters[index])
        {
            return false;
        }
        letters[index] = true;
    }
    return true;
}

// Função para criptografar um caractere usando a chave
char encrypt_char(char c, string key)
{
    if (isupper(c))
    {
        return toupper(key[c - 'A']);
    }
    else if (islower(c))
    {
        return tolower(key[c - 'a']);
    }
    else
    {
        return c;
    }
}
