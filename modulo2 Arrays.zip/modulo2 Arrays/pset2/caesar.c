#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

// Função para verificar se um string contém apenas dígitos
bool only_digits(string s);

int main(int argc, string argv[])
{
    // Verifique se o programa foi executado com um argumento de linha de comando
    if (argc != 2 || !only_digits(argv[1]))
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }

    // Converta o argumento da linha de comando de uma string para int
    int key = atoi(argv[1]);

    // Solicite plaintext: (texto simples) ao usuário
    string plaintext = get_string("plaintext: ");

    printf("ciphertext: ");

    // Itere sobre cada caractere do plaintext
    for (int i = 0, n = strlen(plaintext); i < n; i++)
    {
        char c = plaintext[i];

        // Se é uma letra maiúscula
        if (isupper(c))
        {
            printf("%c", (c - 'A' + key) % 26 + 'A');
        }
        // Se é uma letra minúscula
        else if (islower(c))
        {
            printf("%c", (c - 'a' + key) % 26 + 'a');
        }
        // Se não for nenhum, imprima o caractere como está
        else
        {
            printf("%c", c);
        }
    }

    printf("\n");
    return 0;
}

// Função para verificar se um string contém apenas dígitos
bool only_digits(string s)
{
    for (int i = 0, n = strlen(s); i < n; i++)
    {
        if (!isdigit(s[i]))
        {
            return false;
        }
    }
    return true;
}
