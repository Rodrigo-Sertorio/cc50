#ifndef DICTIONARY_H
#define DICTIONARY_H

#include <stdbool.h>

// Tamanho máximo de uma palavra no dicionário
#define LENGTH 45

// Número de buckets na tabela hash
#define N 10000

// Estrutura de um nó na tabela hash
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
} node;

// Funções
bool check(const char *word);
unsigned int hash(const char *word);
bool load(const char *dictionary);
unsigned int size(void);
bool unload(void);

#endif // DICTIONARY_H
