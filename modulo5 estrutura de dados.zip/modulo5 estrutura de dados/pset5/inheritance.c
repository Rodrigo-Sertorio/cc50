#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct person
{
    struct person *parents[2];
    char alleles[2];
}
person;

// Função para gerar um alelo aleatório (A, B ou O)
char random_allele(void)
{
    int r = rand() % 3; // Gera um número aleatório entre 0 e 2
    if (r == 0)
        return 'A';
    else if (r == 1)
        return 'B';
    else
        return 'O';
}

// Função recursiva para criar uma família com 'generations' gerações
person *create_family(int generations)
{
    // Aloca memória para uma nova pessoa
    person *p = malloc(sizeof(person));

    // Caso base: se for a geração mais jovem (generations == 1)
    if (generations == 1)
    {
        p->parents[0] = NULL;
        p->parents[1] = NULL;
        p->alleles[0] = random_allele();
        p->alleles[1] = random_allele();
    }
    else
    {
        // Cria os pais recursivamente
        p->parents[0] = create_family(generations - 1);
        p->parents[1] = create_family(generations - 1);

        // Atribui alelos aleatórios herdados dos pais
        p->alleles[0] = (rand() % 2 == 0) ? p->parents[0]->alleles[0] : p->parents[0]->alleles[1];
        p->alleles[1] = (rand() % 2 == 0) ? p->parents[1]->alleles[0] : p->parents[1]->alleles[1];
    }

    return p;
}

// Função recursiva para liberar a memória de uma família
void free_family(person *p)
{
    // Caso base: se a pessoa não existe, retorna
    if (p == NULL)
        return;

    // Libera a memória dos pais
    free_family(p->parents[0]);
    free_family(p->parents[1]);

    // Libera a memória da pessoa
    free(p);
}

// Função para imprimir a família
void print_family(person *p, int generation)
{
    // Caso base: se a pessoa não existe, retorna
    if (p == NULL)
        return;

    // Imprime a pessoa na geração atual e seu tipo sanguíneo
    printf("Generation %d, blood type %c%c\n", generation, p->alleles[0], p->alleles[1]);

    // Imprime os filhos, se existirem
    print_family(p->parents[0], generation + 1);
    print_family(p->parents[1], generation + 1);
}

int main(void)
{
    // Semente para o gerador de números aleatórios
    srand(time(NULL));

    // Cria a família com 3 gerações
    person *p = create_family(3);

    // Imprime a família
    print_family(p, 0);

    // Libera a memória alocada para a família
    free_family(p);
}
