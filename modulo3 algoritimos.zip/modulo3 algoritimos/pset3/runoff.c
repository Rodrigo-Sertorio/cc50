#include <cs50.h>
#include <stdio.h>
#include <string.h>

// Máximo de candidatos e eleitores
#define MAX_CANDIDATES 9
#define MAX_VOTERS 100

// Matriz de preferências dos eleitores
int preferences[MAX_VOTERS][MAX_CANDIDATES];

// Estrutura do candidato
typedef struct
{
    string name;
    int votes;
    bool eliminated;
}
candidate;

// Array de candidatos
candidate candidates[MAX_CANDIDATES];

// Variáveis globais
int voter_count;
int candidate_count;

// Protótipos das funções
bool vote(int voter, int rank, string name);
void tabulate(void);
bool print_winner(void);
int find_min(void);
bool is_tie(int min);
void eliminate(int min);

int main(int argc, string argv[])
{
    // Verifica se o número de candidatos é válido
    if (argc < 2)
    {
        printf("Uso: runoff [candidato ...]\n");
        return 1;
    }

    // Preenche o array de candidatos
    candidate_count = argc - 1;
    if (candidate_count > MAX_CANDIDATES)
    {
        printf("Número máximo de candidatos é %i\n", MAX_CANDIDATES);
        return 2;
    }

    for (int i = 0; i < candidate_count; i++)
    {
        candidates[i].name = argv[i + 1];
        candidates[i].votes = 0;
        candidates[i].eliminated = false;
    }

    // Obtém o número de eleitores
    voter_count = get_int("Número de eleitores: ");
    if (voter_count > MAX_VOTERS)
    {
        printf("Número máximo de eleitores é %i\n", MAX_VOTERS);
        return 3;
    }

    // Coleta os votos
    for (int i = 0; i < voter_count; i++)
    {
        for (int j = 0; j < candidate_count; j++)
        {
            string name = get_string("Voto %i: ", j + 1);
            if (!vote(i, j, name))
            {
                printf("Voto inválido.\n");
                return 4;
            }
        }
    }

    // Realiza a eleição por rodadas
    while (true)
    {
        tabulate();  // Conta os votos

        if (print_winner())  // Verifica se há um vencedor
        {
            break;
        }

        int min = find_min();  // Encontra o menor número de votos
        if (is_tie(min))  // Verifica se há um empate
        {
            for (int i = 0; i < candidate_count; i++)
            {
                if (!candidates[i].eliminated)
                {
                    printf("%s\n", candidates[i].name);
                }
            }
            break;
        }

        eliminate(min);  // Elimina o(s) candidato(s) com menos votos
    }

    return 0;
}

// Função para registrar um voto
bool vote(int voter, int rank, string name)
{
    for (int i = 0; i < candidate_count; i++)
    {
        if (strcmp(candidates[i].name, name) == 0)
        {
            preferences[voter][rank] = i;
            return true;
        }
    }
    return false;
}

// Função para contar os votos de candidatos ainda na disputa
void tabulate(void)
{
    for (int i = 0; i < candidate_count; i++)
    {
        candidates[i].votes = 0;
    }

    for (int i = 0; i < voter_count; i++)
    {
        for (int j = 0; j < candidate_count; j++)
        {
            int candidate_index = preferences[i][j];

            if (!candidates[candidate_index].eliminated)
            {
                candidates[candidate_index].votes++;
                break;
            }
        }
    }
}

// Função para verificar se há um vencedor
bool print_winner(void)
{
    int majority = voter_count / 2;

    for (int i = 0; i < candidate_count; i++)
    {
        if (candidates[i].votes > majority)
        {
            printf("%s\n", candidates[i].name);
            return true;
        }
    }
    return false;
}

// Função para encontrar o menor número de votos
int find_min(void)
{
    int min_votes = voter_count;

    for (int i = 0; i < candidate_count; i++)
    {
        if (!candidates[i].eliminated && candidates[i].votes < min_votes)
        {
            min_votes = candidates[i].votes;
        }
    }
    return min_votes;
}

// Função para verificar se há um empate
bool is_tie(int min)
{
    for (int i = 0; i < candidate_count; i++)
    {
        if (!candidates[i].eliminated && candidates[i].votes != min)
        {
            return false;
        }
    }
    return true;
}

// Função para eliminar os candidatos com menos votos
void eliminate(int min)
{
    for (int i = 0; i < candidate_count; i++)
    {
        if (candidates[i].votes == min)
        {
            candidates[i].eliminated = true;
        }
    }
}
