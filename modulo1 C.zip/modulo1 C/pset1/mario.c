#include <stdio.h>

int main(void)
{
    int size;

    // Passo 1: Solicitar o tamanho da pirâmide até o usuário inserir um valor válido.
    do {
        printf("Tamanho: ");  // Solicita ao usuário o tamanho
        scanf("%d", &size);  // Lê a entrada do usuário
    } while (size < 1 || size > 8);  // Valida se o número está entre 1 e 8

    // Passo 2: Criar a pirâmide
    for (int i = 1; i <= size; i++) {  // Itera para cada linha da pirâmide
        // Imprime espaços para centralizar os hashes
        for (int j = 0; j < size - i; j++) {
            printf(" ");
        }

        // Imprime os hashes
        for (int k = 0; k < i; k++) {
            printf("#");
        }

        // Quebra de linha após cada linha de hashes
        printf("\n");
    }

    return 0;
}
