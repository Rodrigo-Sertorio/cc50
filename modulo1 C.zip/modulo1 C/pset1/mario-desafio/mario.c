#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int altura;

    // Solicitar altura entre 1 e 8
    do
    {
        altura = get_int("Altura: ");
    }
    while (altura < 1 || altura > 8);

    // Construção da pirâmide
    for (int i = 1; i <= altura; i++)
    {
        // Imprimir espaços antes dos hashes da primeira pirâmide
        for (int j = 0; j < altura - i; j++)
        {
            printf(" ");
        }

        // Imprimir primeira pirâmide
        for (int j = 0; j < i; j++)
        {
            printf("#");
        }

        // Espaço fixo entre as pirâmides
        printf("  ");

        // Imprimir segunda pirâmide
        for (int j = 0; j < i; j++)
        {
            printf("#");
        }

        // Pular para a próxima linha
        printf("\n");
    }
}
