#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
    float reais;

    // Solicitar um valor válido do usuário
    do
    {
        reais = get_float("Troca devida: ");
    }
    while (reais < 0); // O valor deve ser positivo

    // Converter reais para centavos e arredondar
    int centavos = round(reais * 100);

    // Inicializar contador de moedas
    int moedas = 0;

    // Definir valores das moedas
    int valores[] = {25, 10, 5, 1};

    // Calcular número mínimo de moedas
    for (int i = 0; i < 4; i++)
    {
        moedas += centavos / valores[i]; // Conta quantas moedas do tipo atual cabem
        centavos %= valores[i]; // Atualiza o valor restante
    }

    // Exibir o número mínimo de moedas
    printf("%d\n", moedas);
}
