#include <cs50.h>
#include <stdio.h>

bool check_luhn(long number);
int get_length(long number);
void check_card_brand(long number);

int main(void)
{
    long number;

    // Solicitar um número válido do usuário
    do
    {
        number = get_long("Número: ");
    }
    while (number < 0);

    // Verifica se o número passa no Algoritmo de Luhn
    if (check_luhn(number))
    {
        check_card_brand(number);
    }
    else
    {
        printf("INVALID\n");
    }
}

// Função para verificar se o número passa no Algoritmo de Luhn
bool check_luhn(long number)
{
    int sum = 0;
    bool alternate = false;

    while (number > 0)
    {
        int digit = number % 10;

        if (alternate)
        {
            digit *= 2;
            if (digit > 9)
            {
                digit = (digit % 10) + 1;
            }
        }

        sum += digit;
        number /= 10;
        alternate = !alternate;
    }

    return (sum % 10) == 0;
}

// Função para contar a quantidade de dígitos do número
int get_length(long number)
{
    int length = 0;
    while (number > 0)
    {
        number /= 10;
        length++;
    }
    return length;
}

// Função para determinar a bandeira do cartão
void check_card_brand(long number)
{
    int length = get_length(number);
    int first_two_digits = number / 100000000000000; // Obtém os dois primeiros dígitos
    int first_digit = number / 1000000000000000; // Obtém o primeiro dígito

    if (length == 15 && (first_two_digits == 34 || first_two_digits == 37))
    {
        printf("AMEX\n");
    }
    else if (length == 16 && (first_two_digits >= 51 && first_two_digits <= 55))
    {
        printf("MASTERCARD\n");
    }
    else if ((length == 13 || length == 16) && (first_digit == 4))
    {
        printf("VISA\n");
    }
    else
    {
        printf("INVALID\n");
    }
}
