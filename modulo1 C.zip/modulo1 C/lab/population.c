#include <stdio.h>

int main(void)
{
    int start_size, end_size;

    // Solicita o tamanho inicial ao usuário (deve ser >= 9)
    do
    {
        printf("Start size: ");
        scanf("%d", &start_size);
    }
    while (start_size < 9);

    // Solicita o tamanho final ao usuário (deve ser >= start_size)
    do
    {
        printf("End size: ");
        scanf("%d", &end_size);
    }
    while (end_size < start_size);

    // Calcula o número de anos necessários para atingir o tamanho final
    int years = 0;
    while (start_size < end_size)
    {
        int born = start_size / 3;
        int died = start_size / 4;
        start_size = start_size + born - died;
        years++;
    }

    // Exibe o número de anos necessários
    printf("Years: %d\n", years);

    return 0;
}
